<!DOCTYPE html>
<html lang="ja">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>復習2-5</title>
</head>
<body>
    <?php
    echo '入場料は',$_REQUEST['kubu'],'円です';
    ?>
</body>
</html>