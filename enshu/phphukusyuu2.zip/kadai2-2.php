<!DOCTYPE html>
<html lang="ja">
<head>
    <meta charset="UTF-8">
    <title>復習2-2</title>
</head>
<body>
<?php
    $kubun = ['未就学児','子供料金','小学生～高校生料金','大人料金','65歳以上'];
    foreach($kubun as $c){
        echo $c,'<br>';
    }
?>
</body>
</html>
